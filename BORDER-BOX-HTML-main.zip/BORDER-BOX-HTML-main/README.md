# BASICS FOR CREATING WEBSITE USING HTML



<h4> OUTPUT: </h4>

![image](https://user-images.githubusercontent.com/103377280/196717703-9d772c6a-b620-466a-aec1-8ebba35ea016.png)


Feel free to copy my code for educational purposes.
For more information you may contact me with my social media accounts.


